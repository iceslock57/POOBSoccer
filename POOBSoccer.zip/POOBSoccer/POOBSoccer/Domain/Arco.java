package Domain;
public class Arco {
 private final int posX,posY,ancho,alto; private final String equipoPropietario; private final boolean izquierdo;
 public Arco(int x,int y,int w,int h,String equipo,boolean izquierdo){posX=x;posY=y;ancho=w;alto=h;equipoPropietario=equipo;this.izquierdo=izquierdo;}
 public boolean contieneBalon(Balon b){double y=b.getPosY();int r=b.getRadio();return y-r>posY+5&&y+r<posY+alto-5&&(izquierdo?b.getPosX()+r<=posX:b.getPosX()-r>=posX+ancho);}
 public int getPosX(){return posX;} public int getPosY(){return posY;} public int getAncho(){return ancho;} public int getAlto(){return alto;} public String getEquipoPropietario(){return equipoPropietario;} public boolean isEsArcoIzquierdo(){return izquierdo;}
}
