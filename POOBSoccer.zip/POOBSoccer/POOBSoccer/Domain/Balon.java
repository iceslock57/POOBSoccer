package Domain;

/**
 * Representa el balón del juego.
 * Maneja sus propias físicas básicas de movimiento, gravedad y rebotes.
 */
public class Balon {
    
    private double posX;
    private double posY;
    private double velX;
    private double velY;
    private int radio;
    
    // Constante para la fuerza de gravedad
    private final double GRAVEDAD = 0.42;
    private boolean disparoEspecial;
    private int propietarioDisparo;

    /**
     * Constructor del Balon.
     * 
     * @param x Posición inicial en X.
     * @param y Posición inicial en Y.
     * @param radio Radio del balón para cálculo de colisiones.
     */
    public Balon(double x, double y, int radio) {
        this.posX = x;
        this.posY = y;
        this.radio = radio;
        this.velX = 0;
        this.velY = 0;
    }

    /**
     * Aplica la fuerza de gravedad aumentando la velocidad vertical hacia abajo.
     * El balón está afectado por la gravedad en todo momento.
     */
    public void aplicarGravedad() {
        // Los tiros especiales del anexo son rectos; la gravedad no curva su trayectoria.
        if (!disparoEspecial) this.velY += GRAVEDAD;
    }

    /**
     * Actualiza la posición del balón basándose en su velocidad actual.
     */
    public void mover() {
        this.posX += this.velX;
        this.posY += this.velY;
    }

    /**
     * Maneja el rebote del balón cuando colisiona con los bordes de la cancha.
     * El balón rebota en el suelo y en los bordes[cite: 3].
     * 
     * @param limiteX Ancho de la cancha.
     * @param limiteY Alto de la cancha (suelo).
     */
    public void rebotar(int limiteX, int limiteY) {
        // El techo SIEMPRE es sólido: nunca se puede marcar por encima de la cancha.
        // Rebote en el suelo y techo
        if (this.posY + this.radio >= limiteY) {
            this.posY = limiteY - this.radio;
            this.velY = -this.velY * 0.8; // Pierde un poco de energía al rebotar
        } else if (this.posY - this.radio <= 0) {
            this.posY = this.radio;
            this.velY = -this.velY * 0.8;
        }
        
        // Solo se deja pasar por la abertura vertical real de los arcos.
        boolean alturaDePorteria = this.posY >= limiteY - 150 && this.posY <= limiteY - 25;
        if (this.posX + this.radio >= limiteX && !alturaDePorteria) {
            this.posX = limiteX - this.radio;
            this.velX = -this.velX * 0.8;
        } else if (this.posX - this.radio <= 0 && !alturaDePorteria) {
            this.posX = this.radio;
            this.velX = -this.velX * 0.8;
        }
    }

    /**
     * Rebotes robustos con la geometría real de la cancha.
     * El techo es siempre sólido, incluso durante un disparo especial.
     */
    public void rebotar(Cancha cancha) {
        int ancho = cancha.getAncho();
        int suelo = cancha.getSuelo();
        Arco arco = cancha.getArcoIzquierdo();

        // Techo y suelo se resuelven por separado para no omitir un rebote.
        if (posY - radio <= 0) {
            posY = radio;
            if (velY < 0) velY = Math.abs(velY) * 0.8;
        }
        if (posY + radio >= suelo) {
            posY = suelo - radio;
            if (velY > 0) velY = -Math.abs(velY) * 0.8;
        }

        // Los laterales solo se abren dentro de la boca de las porterías.
        double arriba = arco.getPosY();
        double abajo = arriba + arco.getAlto();
        boolean dentroAbertura = posY - radio >= arriba
                && posY + radio <= abajo;

        if (posX - radio <= 0 && !dentroAbertura) {
            posX = radio;
            if (velX < 0) velX = Math.abs(velX) * 0.8;
        }
        if (posX + radio >= ancho && !dentroAbertura) {
            posX = ancho - radio;
            if (velX > 0) velX = -Math.abs(velX) * 0.8;
        }
    }

    /**
     * Devuelve el balón a una posición específica sin velocidad.
     * Usado después de cada gol para que el balón caiga desde el centro[cite: 3].
     * 
     * @param x Nueva posición X.
     * @param y Nueva posición Y.
     */
    public void resetearPosicion(double x, double y) {
        this.posX = x;
        this.posY = y;
        this.velX = 0;
        this.velY = 0;
        this.disparoEspecial = false;
        this.propietarioDisparo = 0;
    }
    /**
     * Sobrescribe la velocidad actual del balón por una nueva fuerza de impacto.
     */
    public void aplicarFuerza(double fX, double fY) {
        this.velX = fX; this.velY = fY; this.disparoEspecial = false; this.propietarioDisparo = 0;
    }
    public void aplicarDisparoEspecial(double fX, double fY, int propietario) {
        this.velX=fX; this.velY=fY; this.disparoEspecial=true; this.propietarioDisparo=propietario;
    }
    public boolean isDisparoEspecial(){ return disparoEspecial; }
    public int getPropietarioDisparo(){ return propietarioDisparo; }
    public void consumirDisparoEspecial(){ disparoEspecial=false; propietarioDisparo=0; }

    // Getters con estructura estricta

    public double getPosX(){
        return this.posX;
    }

    public double getPosY(){
        return this.posY;
    }

    public double getVelX(){
        return this.velX;
    }

    public double getVelY(){
        return this.velY;
    }

    public int getRadio(){
        return this.radio;
    }
}