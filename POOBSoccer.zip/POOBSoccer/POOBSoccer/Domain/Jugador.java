package Domain;

/** Estado competitivo y carga de poder de cada participante. */
public abstract class Jugador {
    protected String equipo; protected Personaje personaje; protected int golesAnotados, barraPoder, puntos; protected String poderActivo;
    protected final int MAX_PODER=100;
    public Jugador(String equipo,Personaje personaje){this.equipo=equipo;this.personaje=personaje;golesAnotados=0;barraPoder=0;puntos=0;poderActivo="Ninguno";}
    public abstract void realizarAccion(String accion,Partido partido);
    public void cargarPoder(int cantidad){barraPoder=Math.min(MAX_PODER,Math.max(0,barraPoder+cantidad));}
    private int framesCarga;
    public void actualizarCarga(){avanzarCarga();}
    public void avanzarCarga(){framesCarga++;if(framesCarga>=6){cargarPoder(1);framesCarga=0;}}
    public boolean activarPoder(){if(barraPoder<100 || !"Ninguno".equals(poderActivo))return false;barraPoder=0;poderActivo="Preparado";return true;}
    public boolean tienePoderPreparado(){return "Preparado".equals(poderActivo);}
    public void consumirPoder(){poderActivo="Ninguno";}
    public void anotarGol(){golesAnotados++;}
    public String getEquipo(){return equipo;} public Personaje getPersonaje(){return personaje;} public int getGolesAnotados(){return golesAnotados;}
    public void agregarPuntos(int cantidad){puntos+=Math.max(0,cantidad);}
    public int getPuntos(){return puntos;}
    public int getBarraPoder(){return barraPoder;} public String getPoderActivo(){return poderActivo;}
}
