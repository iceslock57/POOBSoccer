package Domain;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase principal de la capa de dominio (Fachada).
 * Administra el estado global del juego usando mapas para inicializar partidos
 * garantizando la extensibilidad sin cascadas de condicionales.
 */
public class POOBSoccer {
    
    private Partido partidoActual;
    private boolean pausa;

    // Interfaces funcionales para el patrón Factory extensible
    private interface ModalidadFactory {
        Jugador[] crearJugadores(Personaje p1, Personaje p2);
    }

    private interface PartidoFactory {
        Partido crearPartido(Jugador j1, Jugador j2);
    }

    // Mapas de configuración
    private Map<String, ModalidadFactory> mapaModalidades;
    private Map<String, PartidoFactory> mapaTiposPartido;

    public POOBSoccer() {
        this.partidoActual = null;
        this.pausa = false;
        
        this.mapaModalidades = new HashMap<>();
        this.mapaTiposPartido = new HashMap<>();
        
        configurarFabricas();
    }

    /**
     * Registra las estrategias de creación en los mapas. 
     * Si a futuro se agrega una nueva modalidad, solo se añade una línea aquí.
     */
    private void configurarFabricas() {
        // Fábricas de Modalidades[cite: 3]
        mapaModalidades.put("PvsP", (p1, p2) -> new Jugador[]{
            new JugadorHumano("Equipo 1", p1, new String[]{"A", "D", "W", "S", "Q"}),
            new JugadorHumano("Equipo 2", p2, new String[]{"LEFT", "RIGHT", "UP", "DOWN", "CTRL"})
        });
        
        // Fábricas de Tipos de Partido[cite: 3]
        mapaTiposPartido.put("Tiempo", (j1, j2) -> new PartidoPorTiempo(j1, j2));
        mapaTiposPartido.put("Goles", (j1, j2) -> new PartidoPorGoles(j1, j2, 5));
    }

    /**
     * Inicia un nuevo partido recuperando la configuración de los mapas (O(1)).
     */
    public void iniciarPartido(String tipo, String modalidad, Personaje p1, Personaje p2) {
        iniciarPartido(tipo,modalidad,p1,p2,5);
    }

    public void iniciarPartido(String tipo,String modalidad,Personaje p1,Personaje p2,int objetivo) {
        if(p1==null||p2==null) throw new ExcepcionJuego("Debe seleccionar ambos personajes");
        ModalidadFactory modFactory=mapaModalidades.get(modalidad);
        if(modFactory==null) throw new ExcepcionJuego("La versión 1 solo incluye Jugador vs Jugador.");
        Jugador[] jugadores=modFactory.crearJugadores(p1,p2);
        if("Tiempo".equals(tipo)) partidoActual=new PartidoPorTiempo(jugadores[0],jugadores[1],objetivo);
        else if("Goles".equals(tipo)) partidoActual=new PartidoPorGoles(jugadores[0],jugadores[1],objetivo);
        else throw new ExcepcionJuego("Tipo de partido no válido: "+tipo);
        pausa=false;
    }

    public void iniciarPartido(String tipo,String modalidad,Personaje p1,Personaje p2,int objetivo,int ancho,int alto) {
        if(p1==null||p2==null) throw new ExcepcionJuego("Debe seleccionar ambos personajes");
        if(!"PvsP".equals(modalidad)) throw new ExcepcionJuego("Esta versión implementa Jugador vs Jugador");
        Jugador j1=new JugadorHumano(p1.getPais(),p1,new String[]{"A","D","W","S","Q"});
        Jugador j2=new JugadorHumano(p2.getPais(),p2,new String[]{"LEFT","RIGHT","UP","DOWN","CTRL"});
        if("Tiempo".equals(tipo)) partidoActual=new PartidoPorTiempo(j1,j2,objetivo,ancho,alto);
        else if("Goles".equals(tipo)) partidoActual=new PartidoPorGoles(j1,j2,objetivo,ancho,alto);
        else throw new ExcepcionJuego("Tipo de partido no válido: "+tipo);
        pausa=false;
    }

    public void pausarJuego() {
        if (this.partidoActual != null && !this.partidoActual.esFinDePartido()) {
            this.pausa = true;
        }
    }

    public void reanudarJuego() {
        if (this.pausa) {
            this.pausa = false;
        }
    }

    public void actualizar() {
        if (this.partidoActual != null && !this.pausa && !this.partidoActual.esFinDePartido()) {
            this.partidoActual.actualizarEstado();
        }
    }

    // Getters con estructura estricta

    public Partido getPartidoActual(){
        return this.partidoActual;
    }

    public boolean isPausa(){
        return this.pausa;
    }
}