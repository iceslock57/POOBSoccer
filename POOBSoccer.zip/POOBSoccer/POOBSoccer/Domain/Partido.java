package Domain;

/** Motor de partido: actualiza física, colisiones, goles y recompensas. */
public abstract class Partido {
 protected Cancha cancha; protected Balon balon; protected Jugador jugador1,jugador2; protected boolean terminado;
 protected int[] marcador; private boolean premiosAsignados;
 public Partido(Jugador j1,Jugador j2){this(j1,j2,1000,650);}
 public Partido(Jugador j1,Jugador j2,int ancho,int alto){
  if(j1==null||j2==null)throw new IllegalArgumentException("Los dos jugadores son obligatorios");
  jugador1=j1;jugador2=j2;marcador=new int[]{0,0};cancha=new Cancha(ancho,alto);balon=new Balon(ancho/2,cancha.getSuelo()-100,16);
  jugador1.getPersonaje().configurarCancha(ancho,cancha.getSuelo());jugador2.getPersonaje().configurarCancha(ancho,cancha.getSuelo());reiniciarPosiciones();
 }
 public void ejecutarPatada(Jugador atacante){
  if(atacante==null)return;Jugador defensor=(atacante==jugador1?jugador2:jugador1);
  Personaje a=atacante.getPersonaje(),d=defensor.getPersonaje();
  double delta=d.getPosX()-a.getPosX();boolean delante=atacante==jugador1?delta>0:delta<0;
  boolean alcance=delante&&Math.abs(delta)<82&&Math.abs(d.getPosY()-a.getPosY())<70;
  if(alcance&&!d.aturdido())d.recibirDanio(10*a.getMultiplicadorKick());
 }
 public void actualizarEstado(){if(terminado)return;
  jugador1.getPersonaje().actualizarEstado();jugador2.getPersonaje().actualizarEstado();jugador1.avanzarCarga();jugador2.avanzarCarga();
  balon.aplicarGravedad();balon.mover();balon.rebotar(cancha);
  detectarImpactoDisparoEspecial();gestionarContacto(jugador1,jugador2,1);gestionarContacto(jugador2,jugador1,-1);
  verificarGol();if(esFinDePartido()){terminado=true;asignarPuntos();}
 }
 private void gestionarContacto(Jugador atacante,Jugador defensor,int direccion){
  Personaje p=atacante.getPersonaje();
  if(balon.isDisparoEspecial() && balon.getPropietarioDisparo()==(atacante==jugador1?1:2))return;
  double bx=balon.getPosX(),by=balon.getPosY();int r=balon.getRadio();
  boolean contacto=bx+r>p.getPosX()&&bx-r<p.getPosX()+42&&by+r>p.getPosY()&&by-r<p.getPosY()+64;
  if(!contacto)return;
  if(p.isPateando()){
   double vx=(atacante.tienePoderPreparado()&&p.getPais().equals("Corea del Sur"))?24:12;
   double vy=atacante.tienePoderPreparado()?-.4:-6.5;
   if(atacante.tienePoderPreparado())balon.aplicarDisparoEspecial(direccion*vx,vy,atacante==jugador1?1:2);
   else balon.aplicarFuerza(direccion*vx,vy);
   atacante.consumirPoder();p.consumirPatada();
  } else if(!balon.isDisparoEspecial()){
   // Rebote suave cuando el balón toca el cuerpo, sin generar daño.
   balon.aplicarFuerza(direccion*3,-2.5);
  }
 }
 private void detectarImpactoDisparoEspecial(){
  if(!balon.isDisparoEspecial())return;
  int owner=balon.getPropietarioDisparo();Jugador defensor=owner==1?jugador2:jugador1;Personaje rival=defensor.getPersonaje();
  double bx=balon.getPosX(),by=balon.getPosY();boolean hit=bx+balon.getRadio()>rival.getPosX()&&bx-balon.getRadio()<rival.getPosX()+42&&by+balon.getRadio()>rival.getPosY()&&by-balon.getRadio()<rival.getPosY()+64;
  if(!hit)return;
  Personaje atacante=(owner==1?jugador1:jugador2).getPersonaje();double mult=atacante.getMultiplicadorKick();
  if("Corea del Sur".equals(atacante.getPais())){rival.recibirDanio(40*mult);rival.aplicarEmpuje(owner==1?1:-1);}
  else if("Camerún".equals(atacante.getPais())){rival.recibirDanio(60*mult);rival.aturdir(3);}
  balon.consumirDisparoEspecial();
 }
 protected void verificarGol(){Arco arco=cancha.esGol(balon);if(arco==null)return;
  if(arco==cancha.getArcoIzquierdo()){marcador[1]++;jugador2.anotarGol();jugador1.cargarPoder(25);}else{marcador[0]++;jugador1.anotarGol();jugador2.cargarPoder(25);}reiniciarPosiciones();
 }
 protected void reiniciarPosiciones(){int suelo=cancha.getSuelo();jugador1.getPersonaje().resetearPosicion(cancha.getAncho()*.22,suelo-64);jugador2.getPersonaje().resetearPosicion(cancha.getAncho()*.74,suelo-64);balon.resetearPosicion(cancha.getAncho()/2,cancha.getAlto()*.32);}
 private void asignarPuntos(){if(premiosAsignados)return;if(marcador[0]>marcador[1]){jugador1.agregarPuntos(100);jugador2.agregarPuntos(25);}else if(marcador[1]>marcador[0]){jugador2.agregarPuntos(100);jugador1.agregarPuntos(25);}else{jugador1.agregarPuntos(25);jugador2.agregarPuntos(25);}premiosAsignados=true;}
 public void terminar(){if(!terminado){terminado=true;asignarPuntos();}}
 protected void finalizarSiCorresponde(){if(esFinDePartido()&&!terminado){terminado=true;asignarPuntos();}}
 public Jugador getGanador(){if(!terminado)return null;if(marcador[0]>marcador[1])return jugador1;if(marcador[1]>marcador[0])return jugador2;return null;}
 public abstract boolean esFinDePartido();
 public int[] getMarcador(){return marcador;}public boolean isTerminado(){return terminado;}public Balon getBalon(){return balon;}public Jugador getJugador1(){return jugador1;}public Jugador getJugador2(){return jugador2;}public Cancha getCancha(){return cancha;}
}
