package Domain;

/** Personaje con movimiento, salto, daño y efectos temporales. */
public class Personaje {
 private final String nombre,pais; private int velocidad,salto,kick,survival; private Poder poderEspecial;
 private double posX,posY,velX,velY; private int framesPateando,framesAturdido,framesEfecto; private int vidaActual;
 private boolean electrificado,confundido; private static final double GRAVEDAD=.48; private static final int ANCHO=42,ALTO=64;
 private int suelo=500,limiteX=1000;
 public Personaje(String n,String p,int v,int s,int k,Poder poder){this(n,p,v,s,k,1,poder);}
 public Personaje(String n,String p,int v,int s,int k,int surv,Poder poder){nombre=n;pais=p;velocidad=limitar(v);salto=limitar(s);kick=limitar(k);survival=limitar(surv);poderEspecial=poder;vidaActual=getVidaMaxima();}
 private int limitar(int x){return Math.max(1,Math.min(10,x));}
 public void configurarCancha(int ancho,int suelo){limiteX=ancho;this.suelo=suelo-ALTO; if(posY>this.suelo)posY=this.suelo;}
 public int getVidaMaxima(){return 100+10*(survival-1);} public double getMultiplicadorKick(){return 1+.10*(kick-1);}
 public void mover(int dir,Personaje rival){if(aturdido())return;double nx=Math.max(0,Math.min(limiteX-ANCHO,posX+dir*velocidad*1.8));boolean choque=nx<rival.posX+ANCHO&&nx+ANCHO>rival.posX&&posY<rival.posY+ALTO&&posY+ALTO>rival.posY;if(!choque)posX=nx;}
 public void saltar(){if(!aturdido()&&posY>=suelo-.1)velY=-(salto*2.7+5);}
 public void patear(){if(!aturdido())framesPateando=12;}
 public void consumirPatada(){framesPateando=0;}
 public void actualizarEstado(){posX=Math.max(0,Math.min(limiteX-ANCHO,posX+velX));velX*=.82;if(Math.abs(velX)<.15)velX=0;velY+=GRAVEDAD;posY+=velY;if(posY>=suelo){posY=suelo;velY=0;}if(framesPateando>0)framesPateando--;if(framesAturdido>0){framesAturdido--;if(framesAturdido==0)vidaActual=getVidaMaxima();}if(framesEfecto>0){framesEfecto--;if(framesEfecto==0){electrificado=false;confundido=false;}}}
 public void recibirDanio(double d){vidaActual=Math.max(0,vidaActual-(int)Math.round(Math.max(0,d)));if(vidaActual==0)aturdir(3);}
 public void aturdir(int s){framesAturdido=Math.max(framesAturdido,s*60);}
 public void aplicarElectrocucion(int s){electrificado=true;framesEfecto=s*60;}
 public void aplicarConfusion(int s){confundido=true;framesEfecto=s*60;}
 public void aplicarEmpuje(int direccion){if(!aturdido())velX=direccion*14.0;}
 public void resetearPosicion(double x,double y){posX=x;posY=y;velX=0;velY=0;framesPateando=framesAturdido=framesEfecto=0;electrificado=confundido=false;vidaActual=getVidaMaxima();}
 public boolean aturdido(){return framesAturdido>0;} public boolean isAturdido(){return aturdido();} public boolean isPateando(){return framesPateando>0;} public boolean isElectrificado(){return electrificado;} public boolean isConfundido(){return confundido;}
 public int getVidaActual(){return vidaActual;} public String getNombre(){return nombre;} public String getPais(){return pais;} public double getPosX(){return posX;} public double getPosY(){return posY;} public int getFuerza(){return kick;} public int getVelocidad(){return velocidad;} public int getSalto(){return salto;} public int getKick(){return kick;} public int getSurvival(){return survival;} public Poder getPoderEspecial(){return poderEspecial;}
}
