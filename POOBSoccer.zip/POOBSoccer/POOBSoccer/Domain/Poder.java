package Domain;
/** Contrato extensible de un tiro especial. */
public interface Poder {
    void aplicarEfecto(Personaje objetivo);
    default void aplicarEfecto(Personaje objetivo,double multiplicadorKick){ aplicarEfecto(objetivo); }
}
