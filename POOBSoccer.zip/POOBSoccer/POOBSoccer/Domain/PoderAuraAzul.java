package Domain;
/** Corea: el dominio aplica el empuje hacia el arco propio del rival. */
public class PoderAuraAzul implements Poder {
 public void aplicarEfecto(Personaje objetivo){aplicarEfecto(objetivo,1.0);}
 public void aplicarEfecto(Personaje objetivo,double multiplicador){objetivo.aplicarEmpuje(1);objetivo.recibirDanio(40*multiplicador);}
}
