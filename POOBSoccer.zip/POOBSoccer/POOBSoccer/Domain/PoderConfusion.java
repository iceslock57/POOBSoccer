package Domain;

/**
 * Poder que invierte los controles de movimiento del oponente[cite: 3].
 */
public class PoderConfusion implements Poder {
    
    private int duracionSegundos;

    public PoderConfusion(int duracionSegundos) {
        this.duracionSegundos = duracionSegundos;
    }

    @Override
    public void aplicarEfecto(Personaje objetivo) {
        // Aquí llamaremos a un método en Personaje para invertir sus físicas/controles
        // objetivo.invertirControles(duracionSegundos);
    }

    public int getDuracionSegundos(){
        return this.duracionSegundos;
    }
}