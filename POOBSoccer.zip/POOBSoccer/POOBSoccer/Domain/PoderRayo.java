package Domain;
/** Camerún: impacto eléctrico recto, velocidad normal y aturdimiento. */
public class PoderRayo implements Poder {
 public void aplicarEfecto(Personaje objetivo){aplicarEfecto(objetivo,1.0);}
 public void aplicarEfecto(Personaje objetivo,double multiplicador){objetivo.recibirDanio(60*multiplicador);objetivo.aturdir(3);}
}
