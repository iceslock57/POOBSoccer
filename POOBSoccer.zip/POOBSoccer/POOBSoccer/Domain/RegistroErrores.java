package Domain;
import java.io.IOException;
import java.util.logging.*;
/** Registro técnico de errores para diagnóstico del equipo. */
public final class RegistroErrores {
    private static final Logger LOGGER=Logger.getLogger("POOBSoccer");
    static {
        try {
            FileHandler archivo=new FileHandler("poobsoccer.log",true);
            archivo.setFormatter(new SimpleFormatter()); LOGGER.addHandler(archivo);
        } catch(IOException e){LOGGER.log(Level.WARNING,"No se pudo crear poobsoccer.log",e);}
    }
    private RegistroErrores(){}
    public static void registrar(String mensaje,Throwable error){LOGGER.log(Level.SEVERE,mensaje,error);}
}
