# Alcance de la Version 1 – DOPOSoccer

Esta entrega se limita a Presentacion + Dominio, maqueta, configuracion, juego basico y Jugador vs Jugador.

## Incluido
- Inicio: Play y Salir.
- Seleccion del tipo de partido: por tiempo o por goles.
- Seleccion de los dos paises implementados: Corea del Sur y Camerun.
- Seleccion de cancha pequena, mediana y grande.
- Jugador vs Jugador en el mismo teclado.
- Fisica del balon: gravedad, rebote en techo, suelo y laterales.
- Goles, marcador, tiempo, gol de oro, pausa y terminar partido.
- Poder de Corea del Sur: disparo recto rapido y empuje.
- Poder de Camerun: disparo recto a velocidad normal y aturdimiento.
- Codigo de dominio, presentacion, pruebas unitarias, diagramas y retrospectiva.

## Fuera del alcance de esta version
- Jugador vs maquina y perfiles de maquina.
- Personajes y poderes de Nigeria y Estados Unidos.
- Persistencia: guardar y abrir partidas.
- Mejoras persistentes de estadisticas y funcionalidades de versiones posteriores.

## Controles
Jugador 1: A/D mover, W saltar, S patear, Q poder.
Jugador 2: flechas mover, flecha arriba saltar, flecha abajo patear, Ctrl poder.
