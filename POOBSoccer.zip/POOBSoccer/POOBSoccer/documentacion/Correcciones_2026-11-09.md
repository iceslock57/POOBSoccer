# Correcciones adicionales – 9 de noviembre de 2026

- Gol: se detecta al cruzar el plano interior de la portería usando la geometría real.
- Funciona con canchas 800x550, 1000x650 y 1200x750.
- El techo permanece sólido y nunca se interpreta como gol.
- Los rebotes laterales usan la abertura exacta de los arcos.
- Selector: botones ANTERIOR y SIGUIENTE evitan caracteres cuadrados.
- Se reemplaza la tarjeta de juego anterior al iniciar otra partida.
- Ctrl del jugador 2 se enlaza con `pressed CONTROL` de Swing.
- Se incluye `tests.RegresionCorrecciones` para validar ambos arcos, tres tamaños, techo y acción CTRL del jugador 2.
