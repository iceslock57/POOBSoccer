# Diagramas de secuencia – DOPOSoccer V1

## 1. Configuración e inicio
```mermaid
sequenceDiagram
 actor Usuario
 participant GUI as POOBSoccerGUI
 participant Facade as POOBSoccer
 participant Partido
 Usuario->>GUI: PLAY y tipo de partido
 Usuario->>GUI: Selecciona países y cancha
 GUI->>Facade: iniciarPartido(tipo, PvsP, p1, p2, meta, ancho, alto)
 Facade->>Partido: crear partido configurado
 Partido-->>Facade: partido listo
 Facade-->>GUI: estado disponible
 GUI-->>Usuario: muestra cancha
```

## 2. Movimiento y patada
```mermaid
sequenceDiagram
 actor Usuario
 participant GUI as POOBSoccerGUI
 participant J as JugadorHumano
 participant P as Personaje
 participant Partido
 participant Balon
 Usuario->>GUI: pulsa D y W
 GUI->>J: realizarAccion(D)
 J->>P: mover(derecha)
 GUI->>J: realizarAccion(W)
 J->>P: saltar()
 Usuario->>GUI: pulsa S
 GUI->>J: realizarAccion(S)
 J->>P: patear()
 J->>Partido: ejecutarPatada(jugador)
 Partido->>P: aplicar daño si rival está al alcance
 Partido->>Balon: aplicar impulso si hay contacto
```

## 3. Tiro especial
```mermaid
sequenceDiagram
 actor Usuario
 participant GUI
 participant Jugador
 participant Personaje
 participant Partido
 participant Balon
 participant Rival
 Usuario->>GUI: pulsa tecla de poder
 GUI->>Jugador: realizarAccion(Q/Ctrl)
 Jugador->>Jugador: valida barra llena y activa aura
 Note over Jugador: aura queda preparada
 Usuario->>GUI: patea cuando está junto al balón
 GUI->>Jugador: realizarAccion(S/Down)
 Partido->>Balon: aplicarDisparoEspecial(velocidad, propietario)
 Balon->>Partido: avanza horizontalmente
 Partido->>Rival: verifica impacto
 alt Corea del Sur
  Partido->>Rival: daño 40 x Kick y empuje progresivo
 else Camerún
  Partido->>Rival: daño 60 x Kick y aturdimiento 3 s
 end
```

## 4. Gol y gol de oro
```mermaid
sequenceDiagram
 participant Balon
 participant Cancha
 participant Partido
 participant Reloj as PartidoPorTiempo
 participant GUI
 Balon->>Cancha: cruza línea lateral
 Cancha-->>Partido: arco válido
 Partido->>Partido: incrementa marcador y reinicia
 Reloj->>Reloj: tiempo llega a cero
 alt marcador empatado
  Reloj->>Reloj: activa gol de oro
  GUI-->>Usuario: muestra ¡GOL DE ORO!
  Partido->>Partido: espera siguiente gol
 else hay ganador
  Partido->>Partido: termina y asigna puntos
 end
```
