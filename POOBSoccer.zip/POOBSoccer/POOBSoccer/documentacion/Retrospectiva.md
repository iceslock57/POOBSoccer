# Retrospectiva – Iteración de correcciones V1

## Qué funcionó
- Se conservó Java, BlueJ, Swing y la separación Domain/presentacion.
- Se centralizaron las reglas de juego en el dominio.
- Se creó una navegación de interfaz que sigue el boceto: inicio, tipo de partido, selección y juego.
- Se incorporaron dimensiones configurables y etiquetas de país.

## Problemas encontrados y correcciones
- El balón podía pasar por la zona superior: el techo ahora es sólido y la validación de gol exige cruzar la línea lateral dentro de la abertura del arco.
- La cancha era pequeña: se ofrecen tres dimensiones y el HUD se escala con la cancha.
- El empate al acabar el tiempo no se comunicaba: ahora se activa gol de oro y se muestra bajo el reloj.
- Los nombres de equipos eran genéricos: se muestran los países elegidos.
- El tiro de Corea desplazaba instantáneamente al rival: ahora aplica una velocidad de empuje que se amortigua gradualmente.
- Camerún no aturdía correctamente: el impacto del tiro especial aplica 3 segundos de aturdimiento.
- La entrada de teclado se gestionaba por eventos individuales: se migró a Swing Key Bindings para aceptar combinaciones simultáneas.

## Qué queda por mejorar
- Implementar completamente poderes de Nigeria y Estados Unidos.
- Añadir sprites, animaciones y efectos gráficos definitivos.
- Completar la tienda de mejoras de estadísticas.
- Aumentar pruebas de integración y pruebas de aceptación con usuarios.
- Validar duración exacta de temporizadores en distintos equipos.

## Próximos pasos
Primero validar manualmente dos partidos completos y ajustar física/colisiones. Después completar el resto de poderes y estadísticas. La persistencia y jugador contra máquina corresponden a la versión siguiente según el plan del proyecto.
