package tests;
import Domain.*;

/** Pruebas de regresion de los requisitos de la Version 1. */
public class RegresionVersionUno {
    private static void check(boolean ok, String msg) {
        if (!ok) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        int checks=0;
        int[][] sizes={{800,550},{1000,650},{1200,750}};
        for(int[] size:sizes){
            Cancha c=new Cancha(size[0],size[1]);
            Arco left=c.getArcoIzquierdo(), right=c.getArcoDerecho();
            double y=left.getPosY()+left.getAlto()/2.0;
            Balon roof=new Balon(size[0]/2.0,18,10);
            roof.aplicarFuerza(0,-8); roof.mover(); roof.rebotar(c);
            check(roof.getPosY()>=roof.getRadio(),"El balon atraviesa el techo"); checks++;
            check(roof.getVelY()>0,"El balon no rebota hacia abajo en el techo"); checks++;

            Balon bl=new Balon(left.getPosX()+left.getAncho()+8,y,10);
            bl.aplicarFuerza(-12,0); bl.mover();
            check(c.esGol(bl)==left,"No detecta gol izquierdo en "+size[0]); checks++;
            Balon br=new Balon(right.getPosX()-8,y,10);
            br.aplicarFuerza(12,0); br.mover();
            check(c.esGol(br)==right,"No detecta gol derecho en "+size[0]); checks++;
        }
        Personaje korea=new Personaje("Corea","Corea del Sur",3,3,3,new PoderAuraAzul());
        Personaje cameroon=new Personaje("Camerun","Camerún",3,3,3,new PoderRayo());
        JugadorHumano j1=new JugadorHumano("Corea",korea,new String[]{"A","D","W","S","Q"});
        JugadorHumano j2=new JugadorHumano("Camerún",cameroon,new String[]{"LEFT","RIGHT","UP","DOWN","CTRL"});
        PartidoPorGoles match=new PartidoPorGoles(j1,j2,5);
        j2.cargarPoder(100);
        j2.realizarAccion("CTRL",match);
        check(j2.tienePoderPreparado(),"La accion CTRL del jugador 2 no activa el poder"); checks++;
        j1.cargarPoder(100);j1.realizarAccion("Q",match);
        check(j1.tienePoderPreparado(),"La accion Q del jugador 1 no activa el poder"); checks++;
        System.out.println("Version 1: "+checks+" pruebas superadas.");
    }
}
