package Domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Registro de personajes disponibles: pais -> poder. */
public final class CatalogoPersonajes {

    private static final Map<String, Supplier<Poder>> PODERES = new LinkedHashMap<>();

    static {
        PODERES.put("Corea del Sur", PoderAuraAzul::new);
        PODERES.put("Camerún", PoderRayo::new);
        PODERES.put("Rusia", PoderHielo::new);
        PODERES.put("Japón", PoderTornado::new);
    }

    private CatalogoPersonajes() {
    }

    public static List<String> paises() {
        return new ArrayList<>(PODERES.keySet());
    }

    public static boolean existe(String pais) {
        return PODERES.containsKey(pais);
    }

    public static Personaje crear(String pais) {
        Supplier<Poder> fabrica = PODERES.get(pais);

        if (fabrica == null) {
            throw new IllegalArgumentException("País sin poder definido: " + pais);
        }

        return new Personaje(pais, pais, 3, 3, 3, 3, fabrica.get());
    }
}