package Domain;

/** Motor de partido: actualiza física, colisiones, goles y recompensas. */
public abstract class Partido {

    private static final int ANCHO = Personaje.ANCHO, ALTO = Personaje.ALTO;
    // Distancia a la que una patada alcanza al rival (casi dos cuerpos al frente y un poco más que su altura).
    private static final int ALCANCE_PATADA_X = ANCHO * 2 - 2, ALCANCE_PATADA_Y = ALTO + 6;

    protected Cancha cancha;
    protected Balon balon;
    protected Jugador jugador1, jugador2;
    protected boolean terminado;
    protected int[] marcador;
    private boolean premiosAsignados;

    public Partido(Jugador j1, Jugador j2) {
        this(j1, j2, 1000, 650);
    }

    public Partido(Jugador j1, Jugador j2, int ancho, int alto) {
        if (j1 == null || j2 == null) throw new IllegalArgumentException("Los dos jugadores son obligatorios");
        jugador1 = j1;
        jugador2 = j2;
        marcador = new int[]{0, 0};
        cancha = new Cancha(ancho, alto);
        balon = new Balon(ancho / 2, cancha.getSuelo() - 100, 16);
        // Cada personaje necesita conocer los límites de la cancha para moverse dentro de ella.
        jugador1.getPersonaje().configurarCancha(ancho, cancha.getSuelo());
        jugador2.getPersonaje().configurarCancha(ancho, cancha.getSuelo());
        reiniciarPosiciones();
    }

    /**
     * Registra la patada del personaje. La animación se inicia desde JugadorHumano;
     * el balón se impulsa en gestionarContacto cuando realmente alcanza al jugador.
     * Si el rival está delante y muy cerca, también recibe el golpe físico de la patada.
     */
    public void ejecutarPatada(Jugador atacante) {
        if (atacante == null) return;

        // Se identifica al contrario para comprobar si la patada también lo alcanza.
        Jugador defensor = atacante == jugador1 ? jugador2 : jugador1;
        Personaje a = atacante.getPersonaje();
        Personaje d = defensor.getPersonaje();
        int direccion = atacante == jugador1 ? 1 : -1;
        double separacion = d.getPosX() - a.getPosX();

        boolean rivalDelante = separacion * direccion > 0;
        boolean dentroDelAlcance = Math.abs(separacion) < ALCANCE_PATADA_X
                && Math.abs(d.getPosY() - a.getPosY()) < ALCANCE_PATADA_Y;

        if (rivalDelante && dentroDelAlcance && !d.aturdido()) {
            d.recibirDanio(10 * a.getMultiplicadorKick());
        }
    }

    /**
     * Actualiza el partido en cada cuadro: física, disparos, colisiones y goles.
     * La habilidad especial no se aplica al tocar al otro personaje; viaja dentro
     * del balón y produce su efecto cuando ese balón impacta al rival.
     */
    public void actualizarEstado() {
        if (terminado) return;

        // Primero avanzan los personajes y se acumula poco a poco la energía de sus poderes.
        jugador1.getPersonaje().actualizarEstado();
        jugador2.getPersonaje().actualizarEstado();
        jugador1.avanzarCarga();
        jugador2.avanzarCarga();

        // Después se mueve el balón y se corrigen sus rebotes contra la cancha.
        balon.aplicarGravedad();
        balon.mover();
        balon.rebotar(cancha);

        // Un disparo especial puede aplicar el poder si alcanza al personaje contrario.
        detectarImpactoDisparoEspecial();

        // Las colisiones ordinarias determinan si el balón rebota o sale pateado.
        gestionarContacto(jugador1, jugador2, 1);
        gestionarContacto(jugador2, jugador1, -1);

        verificarGol();
        if (esFinDePartido()) {
            terminado = true;
            asignarPuntos();
        }
    }

    /**
     * Devuelve la velocidad horizontal que corresponde a la habilidad preparada.
     * Cada poder puede definir su propia velocidad; sin poder, se usa el disparo normal.
     */
    private static double velocidadDisparo(Personaje personaje, boolean poderPreparado) {
        Poder poder = personaje.getPoderEspecial();
        return poderPreparado && poder != null ? poder.velocidadDisparo() : 12;
    }

    /**
     * Comprueba si el balón toca el cuerpo de uno de los jugadores.
     * Si el jugador está pateando, el contacto convierte esa acción en un disparo:
     * normal cuando no preparó habilidad y especial cuando sí la preparó.
     */
    private void gestionarContacto(Jugador atacante, Jugador defensor, int direccion) {
        Personaje personaje = atacante.getPersonaje();

        // Un disparo especial no puede volver a impactar al mismo jugador que lo lanzó.
        int propietario = atacante == jugador1 ? 1 : 2;
        if (balon.isDisparoEspecial() && balon.getPropietarioDisparo() == propietario) {
            return;
        }

        double bx = balon.getPosX();
        double by = balon.getPosY();
        int radio = balon.getRadio();
        boolean contacto = bx + radio > personaje.getPosX()
                && bx - radio < personaje.getPosX() + ANCHO
                && by + radio > personaje.getPosY()
                && by - radio < personaje.getPosY() + ALTO;

        if (!contacto) return;

        if (personaje.isPateando()) {
            // Una habilidad solo se consume cuando la patada alcanza al balón.
            boolean poderPreparado = atacante.tienePoderPreparado()
                    && personaje.getPoderEspecial() != null;
            double velocidadX = velocidadDisparo(personaje, poderPreparado);
            double velocidadY = poderPreparado ? -0.4 : -6.5;

            if (poderPreparado) {
                // El balón queda marcado con su dueño para aplicar el poder al golpear al contrario.
                balon.aplicarDisparoEspecial(direccion * velocidadX, velocidadY, propietario);
            } else {
                // Sin habilidad preparada, la patada mantiene el impulso normal del juego.
                balon.aplicarFuerza(direccion * velocidadX, velocidadY);
            }

            if (atacante.tienePoderPreparado()) {
                atacante.consumirPoder();
            }
            personaje.consumirPatada();
        } else if (!balon.isDisparoEspecial()) {
            // Si el balón llega sin una patada, rebota suavemente contra el cuerpo.
            balon.aplicarFuerza(direccion * 3, -2.5);
        }
    }

    /**
     * Revisa si un balón especial ya llegó al rival. El poder de cada personaje
     * define el daño y el estado que aplica; esta clase solo coordina el impacto.
     */
    private void detectarImpactoDisparoEspecial() {
        if (!balon.isDisparoEspecial()) return;

        int propietario = balon.getPropietarioDisparo();
        Jugador defensor = propietario == 1 ? jugador2 : jugador1;
        Personaje rival = defensor.getPersonaje();

        double bx = balon.getPosX();
        double by = balon.getPosY();
        int radio = balon.getRadio();
        boolean impacto = bx + radio > rival.getPosX()
                && bx - radio < rival.getPosX() + ANCHO
                && by + radio > rival.getPosY()
                && by - radio < rival.getPosY() + ALTO;

        if (!impacto) return;

        Personaje atacante = (propietario == 1 ? jugador1 : jugador2).getPersonaje();
        Poder poder = atacante.getPoderEspecial();
        if (poder != null) {
            poder.aplicarImpacto(rival, atacante.getMultiplicadorKick(), propietario == 1 ? 1 : -1);
        }

        // Al impactar, el disparo especial se desmarca para que no afecte varias veces.
        balon.consumirDisparoEspecial();
    }

    protected void verificarGol() {
        Arco arco = cancha.esGol(balon);
        if (arco == null) return;
        // Quien recibe el gol gana carga de poder para intentar remontar.
        if (arco == cancha.getArcoIzquierdo()) {
            marcador[1]++;
            jugador2.anotarGol();
            jugador1.cargarPoder(25);
        } else {
            marcador[0]++;
            jugador1.anotarGol();
            jugador2.cargarPoder(25);
        }
        reiniciarPosiciones();
    }

    protected void reiniciarPosiciones() {
        int suelo = cancha.getSuelo();
        jugador1.getPersonaje().resetearPosicion(cancha.getAncho() * .22, suelo - ALTO);
        jugador2.getPersonaje().resetearPosicion(cancha.getAncho() * .74, suelo - ALTO);
        balon.resetearPosicion(cancha.getAncho() / 2, cancha.getAlto() * .32);
    }

    private void asignarPuntos() {
        // Los premios se entregan una sola vez, aunque el partido se termine por varias vías.
        if (premiosAsignados) return;
        if (marcador[0] > marcador[1]) {
            jugador1.agregarPuntos(100);
            jugador2.agregarPuntos(25);
        } else if (marcador[1] > marcador[0]) {
            jugador2.agregarPuntos(100);
            jugador1.agregarPuntos(25);
        } else {
            jugador1.agregarPuntos(25);
            jugador2.agregarPuntos(25);
        }
        premiosAsignados = true;
    }

    public void terminar() {
        if (!terminado) {
            terminado = true;
            asignarPuntos();
        }
    }

    protected void finalizarSiCorresponde() {
        if (esFinDePartido() && !terminado) {
            terminado = true;
            asignarPuntos();
        }
    }

    public Jugador getGanador() {
        if (!terminado) return null;
        if (marcador[0] > marcador[1]) return jugador1;
        if (marcador[1] > marcador[0]) return jugador2;
        return null;
    }

    public abstract boolean esFinDePartido();

    public int[] getMarcador() { return marcador; }
    public boolean isTerminado() { return terminado; }
    public Balon getBalon() { return balon; }
    public Jugador getJugador1() { return jugador1; }
    public Jugador getJugador2() { return jugador2; }
    public Cancha getCancha() { return cancha; }
}