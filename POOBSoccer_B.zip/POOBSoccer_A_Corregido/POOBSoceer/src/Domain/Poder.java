package Domain;

/** Contrato extensible de un tiro especial. */
public interface Poder {

    void aplicarEfecto(Personaje objetivo);

    default void aplicarEfecto(Personaje objetivo, double multiplicadorKick) {
        aplicarEfecto(objetivo);
    }

    /** Velocidad horizontal del disparo especial. */
    default double velocidadDisparo() {
        return 12;
    }

    /** Efecto al impactar; direccion es +1 (hacia la derecha) o -1. */
    default void aplicarImpacto(Personaje rival, double multiplicadorKick, int direccion) {
        aplicarEfecto(rival, multiplicadorKick);
    }
}