package Domain;

/**
 * Poder que invierte los controles de movimiento del oponente.
 */
public class PoderConfusion implements Poder {
    
    private int duracionSegundos;

    public PoderConfusion(int duracionSegundos) {
        this.duracionSegundos = duracionSegundos;
    }

    @Override
    public void aplicarEfecto(Personaje objetivo) {
        // La confusión invierte temporalmente las órdenes de movimiento del rival.
        objetivo.aplicarConfusion(duracionSegundos);
    }

    public int getDuracionSegundos(){
        return this.duracionSegundos;
    }
}