package Domain;

/** Congela al rival: poco daño y no puede actuar durante unos segundos. */
public class PoderHielo implements Poder {
    private static final double DANIO_BASE = 20;
    private static final int SEGUNDOS_CONGELADO = 3;

    @Override public void aplicarEfecto(Personaje objetivo) { aplicarEfecto(objetivo, 1.0); }

    @Override public void aplicarEfecto(Personaje objetivo, double multiplicadorKick) {
        objetivo.recibirDanio(DANIO_BASE * multiplicadorKick);
        objetivo.congelar(SEGUNDOS_CONGELADO);
    }
}