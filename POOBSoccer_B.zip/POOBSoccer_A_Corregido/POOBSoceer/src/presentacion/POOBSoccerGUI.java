package presentacion;

import Domain.*;
import javax.swing.*;
import java.awt.*;

/** Interfaz con flujo Inicio -> Tipo de partido -> Selección de países -> Juego. */
public class POOBSoccerGUI extends JFrame {

    private final POOBSoccer dominio = new POOBSoccer();
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private PantallaJuego pantallaJuego;
    private Timer loop;
    private String tipoPartido = "Tiempo";
    private int anchoCancha = 1000, altoCancha = 650;
    private PantallaSeleccion seleccion;
    private final ControladorTeclado teclado;

    public POOBSoccerGUI() {
        super("DOPOSoccer");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(760, 520));
        root.add(new PantallaInicio(() -> cards.show(root, "tipos"), this::dispose), "inicio");
        root.add(new PantallaTipos(this::elegirTipo, () -> cards.show(root, "inicio")), "tipos");
        seleccion = new PantallaSeleccion(this::iniciarPartida, () -> cards.show(root, "tipos"));
        root.add(seleccion, "seleccion");
        setContentPane(root);
        // Tamaño inicial suficiente para que las tarjetas de los países se vean completas.
        setSize(1000, 650);
        setLocationRelativeTo(null);
        teclado = new ControladorTeclado(dominio, root, this::repintarJuego);
        // Si la ventana pierde el foco (por ejemplo con Alt+Tab) no llega el "soltar" de las teclas;
        // se olvidan para que ningún jugador siga moviéndose solo.
        addWindowFocusListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowLostFocus(java.awt.event.WindowEvent e) {
                teclado.reiniciar();
            }
        });
        // Bucle del juego: ~60 cuadros por segundo.
        loop = new Timer(16, e -> {
            Partido actual = dominio.getPartidoActual();
            if (actual != null && !dominio.isPausa() && !actual.isTerminado()) {
                teclado.procesarTeclasContinuas();
                dominio.actualizar();
            }
            repintarJuego();
        });
    }

    private void repintarJuego() {
        if (pantallaJuego != null) pantallaJuego.repintar();
    }

    // ===================== Pantallas =====================

    /** Se llama desde PantallaTipos con "Tiempo" o "Goles". */
    private void elegirTipo(String tipo) {
        tipoPartido = tipo;
        seleccion.prepararPara(tipo);
        cards.show(root, "seleccion");
    }

    // ===================== Inicio del juego =====================

    /** Se llama desde PantallaSeleccion al presionar JUGAR. */
    private void iniciarPartida() {
        anchoCancha = seleccion.getAnchoCancha();
        altoCancha = seleccion.getAltoCancha();
        int objetivo = seleccion.getObjetivo();
        // El catálogo decide qué poder le toca a cada país.
        Personaje p1 = CatalogoPersonajes.crear(seleccion.getPais1());
        Personaje p2 = CatalogoPersonajes.crear(seleccion.getPais2());
        try {
            dominio.iniciarPartido(tipoPartido, "PvsP", p1, p2, objetivo, anchoCancha, altoCancha);
            mostrarJuego();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo iniciar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarJuego() {
        loop.stop();
        teclado.reiniciar();
        // Si ya había una partida anterior, se retira su pantalla antes de agregar la nueva.
        if (pantallaJuego != null) root.remove(pantallaJuego);
        pantallaJuego = new PantallaJuego(dominio, this::volverAlMenu);
        root.add(pantallaJuego, "juego");
        cards.show(root, "juego");
        setSize(anchoCancha, altoCancha + 95);
        setLocationRelativeTo(null);
        pantallaJuego.enfocar();
        loop.start();
    }

    /** Se llama desde PantallaJuego al presionar MENÚ. */
    private void volverAlMenu() {
        loop.stop();
        cards.show(root, "inicio");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new POOBSoccerGUI().setVisible(true));
    }
}