package Domain;

/** Tornado: disparo rapido que empuja con fuerza y confunde al rival. */
public class PoderTornado implements Poder {
    private static final double DANIO_BASE = 30;
    private static final int SEGUNDOS_CONFUSION = 3;
    @Override public double velocidadDisparo() {
        return 18;
    }
    @Override public void aplicarEfecto(Personaje objetivo) {
        aplicarEfecto(objetivo, 1.0);
    }
    @Override public void aplicarEfecto(Personaje objetivo, double multiplicadorKick) {
        objetivo.recibirDanio(DANIO_BASE * multiplicadorKick);
        objetivo.aplicarConfusion(SEGUNDOS_CONFUSION);
    }
    @Override public void aplicarImpacto(Personaje rival, double mult, int direccion) {
        aplicarEfecto(rival, mult);
        rival.aplicarEmpuje(direccion);
    }
}
