DOPOSoccer - Version 1 (Presentacion + Dominio)
================================================
IDE actual: BlueJ. Lenguaje: Java 8 o superior. Interfaz: Swing.

ABRIR EN BLUEJ
1. Descomprima el ZIP completo.
2. En BlueJ seleccione Project > Open Project.
3. Abra la carpeta POOBSoccer.
4. Compile el proyecto.
5. Abra el paquete presentacion, haga clic derecho en POOBSoccerGUI y ejecute
   void main(String[] args).

FLUJO DE PANTALLAS
Inicio (PLAY / SALIR) -> Tipo de partido (Tiempo / Goles) -> Seleccion de
paises para ambos jugadores + tamano de cancha + duracion/meta -> JUGAR.

CONTROLES
Jugador 1: A izquierda, D derecha, W saltar, S patear, Q activar poder.
Jugador 2: flechas izquierda/derecha, arriba saltar, abajo patear, Ctrl poder.
Las teclas se gestionan mediante Swing Key Bindings, por lo que W+D puede
registrarse simultaneamente.

CANCHAS
Pequena: 800 x 550. Mediana: 1000 x 650. Grande: 1200 x 750.
El techo es solido y el gol solo se reconoce al cruzar una linea lateral dentro
de la abertura vertical de una porteria.

PODERES IMPLEMENTADOS EN ESTA ITERACION
Corea del Sur: al activar Q se muestra aura. Al patear/tocar el balon se lanza
un tiro horizontal rapido (24 unidades por frame). Si impacta al rival, aplica
40 x multiplicadorKick de dano y un empuje progresivo hacia el arco propio.
Camerun: al activar Ctrl se muestra aura. Al patear/tocar el balon se lanza un
tiro horizontal a velocidad normal (12 unidades por frame). Si impacta al rival,
aplica 60 x multiplicadorKick de dano y lo aturde 3 segundos.

NOTA DE ALCANCE
Nigeria y Estados Unidos aparecen como personajes seleccionables, pero sus
poderes no estan completados conforme al anexo del PDF. Guardar/abrir partidas,
maquina, tienda de estadisticas y efectos visuales avanzados pertenecen a
iteraciones posteriores o siguen pendientes. No se declara cumplido aquello
que aun no esta implementado.

PRUEBAS
En BlueJ ejecute tests.PruebasDominio como aplicacion. Tambien puede compilar
desde una terminal situada en la carpeta POOBSoccer:
  javac -encoding UTF-8 Domain/*.java presentacion/*.java tests/*.java
  java tests.PruebasDominio

MIGRACION A VISUAL STUDIO CODE
1. Instale un JDK (17 recomendado) y Extension Pack for Java.
2. Abra la carpeta POOBSoccer con File > Open Folder.
3. Compile con el comando javac anterior o configure un proyecto Java.
4. Ejecute presentacion.POOBSoccerGUI como clase principal.
