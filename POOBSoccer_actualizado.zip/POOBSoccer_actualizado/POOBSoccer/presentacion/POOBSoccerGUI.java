package presentacion;

import Domain.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Interfaz con flujo Inicio -> Tipo de partido -> Selección de países -> Juego. */
public class POOBSoccerGUI extends JFrame {
    private final POOBSoccer dominio = new POOBSoccer();
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private PanelCancha panelCancha;
    private JPanel pantallaJuego;
    private Timer loop;
    private String tipoPartido = "Tiempo";
    // La lista sale del catálogo, así que agregar un personaje nuevo no obliga a tocar esta clase.
    private final java.util.List<String> paises = CatalogoPersonajes.paises();
    private int indice1 = 0, indice2 = 1, anchoCancha = 1000, altoCancha = 650, objetivo = 2;
    private JLabel paisJ1, paisJ2, modoLabel;
    private JComboBox<String> comboCancha;
    private JSpinner spinnerObjetivo;
    private final java.util.Set<Integer> teclasPresionadas = new java.util.HashSet<>();
    private boolean controlPresionado = false;
    // CTRL se captura a nivel global para que funcione sin importar qué componente tenga el foco.
    private final KeyEventDispatcher dispatcherControl = evento -> {
        if (evento.getID() == KeyEvent.KEY_RELEASED && evento.getKeyCode() == KeyEvent.VK_CONTROL) {
            controlPresionado = false;
        }
        else if (evento.getID() == KeyEvent.KEY_PRESSED && evento.getKeyCode() == KeyEvent.VK_CONTROL) {
            // Solo dispara la acción en la primera pulsación, no mientras se mantiene presionada.
            if (!controlPresionado) {
                controlPresionado = true;
                accion(2, "CTRL");
            }
            return true;
        }
        return false;
    }
    ;
    public POOBSoccerGUI() {
        super("DOPOSoccer");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(760, 520));
        root.add(crearInicio(), "inicio");
        root.add(crearTipos(), "tipos");
        root.add(crearSeleccion(), "seleccion");
        setContentPane(root);
        setLocationRelativeTo(null);
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(dispatcherControl);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                KeyboardFocusManager.getCurrentKeyboardFocusManager().removeKeyEventDispatcher(dispatcherControl);
            }
        }
        );
        // Bucle del juego: ~60 cuadros por segundo.
        loop = new Timer(16, e -> {
            Partido actual = dominio.getPartidoActual();
            if (actual != null && !dominio.isPausa() && !actual.isTerminado()) {
                procesarTeclasContinuas();
                dominio.actualizar();
            }
            if (panelCancha != null) panelCancha.repaint();
        }
        );
        instalarControles();
    }
    // ===================== Componentes reutilizables =====================
    private JPanel fondo(String titulo) {
        JPanel p = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D x = (Graphics2D) g;
                x.setPaint(new GradientPaint(0, 0, new Color(15, 34, 66), 0, getHeight(), new Color(26, 116, 93)));
                x.fillRect(0, 0, getWidth(), getHeight());
            }
        }
        ;
        p.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));
        return p;
    }
    private JLabel titulo(String s, int size) {
        JLabel l = new JLabel(s, SwingConstants.CENTER);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("Arial", Font.BOLD, size));
        return l;
    }
    private JButton boton(String s) {
        JButton b = new JButton(s);
        b.setFont(new Font("Arial", Font.BOLD, 20));
        b.setFocusPainted(false);
        b.setBackground(new Color(255, 205, 55));
        b.setForeground(new Color(25, 35, 55));
        b.setPreferredSize(new Dimension(250, 54));
        return b;
    }
    // ===================== Pantallas =====================
    private JPanel crearInicio() {
        JPanel p = fondo("DOPOSoccer");
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel logo = titulo("HEAD SOCCER", 42);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        box.add(logo);
        box.add(Box.createVerticalStrut(45));
        JButton play = boton("PLAY");
        play.setAlignmentX(Component.CENTER_ALIGNMENT);
        play.addActionListener(e -> cards.show(root, "tipos"));
        box.add(play);
        box.add(Box.createVerticalStrut(15));
        JButton salir = boton("SALIR");
        salir.setAlignmentX(Component.CENTER_ALIGNMENT);
        salir.addActionListener(e -> dispose());
        box.add(salir);
        p.add(box);
        return p;
    }
    private JPanel crearTipos() {
        JPanel p = fondo("TIPOS DE JUEGO");
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel h = titulo("SELECCIONA EL TIPO DE PARTIDO", 28);
        h.setAlignmentX(Component.CENTER_ALIGNMENT);
        box.add(h);
        box.add(Box.createVerticalStrut(35));
        JButton tiempo = boton("PARTIDO POR TIEMPO");
        tiempo.setAlignmentX(Component.CENTER_ALIGNMENT);
        tiempo.addActionListener(e -> {
            tipoPartido = "Tiempo";
            cards.show(root, "seleccion");
            actualizarSeleccion();
        }
        );
        box.add(tiempo);
        box.add(Box.createVerticalStrut(18));
        JButton goles = boton("PARTIDO POR GOLES");
        goles.setAlignmentX(Component.CENTER_ALIGNMENT);
        goles.addActionListener(e -> {
            tipoPartido = "Goles";
            cards.show(root, "seleccion");
            actualizarSeleccion();
        }
        );
        box.add(goles);
        box.add(Box.createVerticalStrut(25));
        JButton volver = boton("VOLVER");
        volver.setAlignmentX(Component.CENTER_ALIGNMENT);
        volver.addActionListener(e -> cards.show(root, "inicio"));
        box.add(volver);
        p.add(box);
        return p;
    }
    private JPanel crearSeleccion() {
        JPanel p = fondo("SELECCIÓN DE PERSONAJES");
        p.setLayout(new BorderLayout(15, 15));
        JLabel h = titulo("ELIGE LOS PAÍSES Y CONFIGURA LA CANCHA", 26);
        p.add(h, BorderLayout.NORTH);
        JPanel centro = new JPanel(new GridLayout(1, 2, 30, 0));
        centro.setOpaque(false);
        centro.add(crearSelectorJugador(1));
        centro.add(crearSelectorJugador(2));
        p.add(centro, BorderLayout.CENTER);
        JPanel sur = new JPanel();
        sur.setOpaque(false);
        sur.setLayout(new BoxLayout(sur, BoxLayout.Y_AXIS));
        JPanel opciones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));
        opciones.setOpaque(false);
        JLabel canchaLabel = new JLabel("Tamaño de cancha:");
        canchaLabel.setForeground(Color.WHITE);
        canchaLabel.setFont(new Font("Arial", Font.BOLD, 16));
        comboCancha = new JComboBox<>(new String[] {
            "Pequeña (800 x 550)", "Mediana (1000 x 650)", "Grande (1200 x 750)"
        }
        );
        comboCancha.setSelectedIndex(1);
        // Esta etiqueta cambia según el tipo de partido (duración o goles), por eso se guarda en modoLabel.
        JLabel objetivoLabel = new JLabel();
        objetivoLabel.setForeground(Color.WHITE);
        objetivoLabel.setFont(new Font("Arial", Font.BOLD, 16));
        spinnerObjetivo = new JSpinner(new SpinnerNumberModel(2, 1, 10, 1));
        modoLabel = objetivoLabel;
        opciones.add(canchaLabel);
        opciones.add(comboCancha);
        opciones.add(objetivoLabel);
        opciones.add(spinnerObjetivo);
        sur.add(opciones);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 8));
        botones.setOpaque(false);
        JButton atras = boton("VOLVER");
        atras.addActionListener(e -> cards.show(root, "tipos"));
        botones.add(atras);
        JButton iniciar = boton("JUGAR");
        iniciar.addActionListener(e -> iniciarPartida());
        botones.add(iniciar);
        sur.add(botones);
        p.add(sur, BorderLayout.SOUTH);
        return p;
    }
    private JPanel crearSelectorJugador(int jugador) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(new Color(255, 255, 255, 225));
        p.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(Color.WHITE, 4),
        BorderFactory.createEmptyBorder(15, 15, 15, 15)));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 3;
        c.insets = new Insets(8, 8, 18, 8);
        p.add(new JLabel("JUGADOR " + jugador), c);
        c.gridy++;
        c.gridwidth = 1;
        JButton izq = new JButton("<<");
        izq.setFont(new Font("Arial", Font.BOLD, 16));
        izq.setPreferredSize(new Dimension(54, 42));
        c.gridx = 0;
        p.add(izq, c);
        JLabel pais = new JLabel("", SwingConstants.CENTER);
        pais.setFont(new Font("Arial", Font.BOLD, 18));
        pais.setOpaque(true);
        pais.setBackground(Color.WHITE);
        pais.setPreferredSize(new Dimension(160, 80));
        pais.setMinimumSize(new Dimension(140, 70));
        c.gridx = 1;
        p.add(pais, c);
        JButton der = new JButton(">>");
        der.setFont(new Font("Arial", Font.BOLD, 16));
        der.setPreferredSize(new Dimension(54, 42));
        c.gridx = 2;
        p.add(der, c);
        // "<<" retrocede y ">>" avanza por la lista completa de países.
        izq.addActionListener(e -> cambiar(jugador, -1));
        der.addActionListener(e -> cambiar(jugador, 1));
        if (jugador == 1) paisJ1 = pais;
        else paisJ2 = pais;
        return p;
    }
    // ===================== Selección de países =====================
    /** Mueve la selección del jugador; floorMod hace que la lista dé la vuelta en ambos sentidos. */
    private void cambiar(int jugador, int paso) {
        int n = paises.size();
        if (jugador == 1) indice1 = Math.floorMod(indice1 + paso, n);
        else indice2 = Math.floorMod(indice2 + paso, n);
        refrescarPaises();
    }
    private void refrescarPaises() {
        if (paisJ1 != null) paisJ1.setText(paises.get(indice1));
        if (paisJ2 != null) paisJ2.setText(paises.get(indice2));
    }
    private void actualizarSeleccion() {
        refrescarPaises();
        if (modoLabel != null) modoLabel.setText(tipoPartido.equals("Tiempo") ? "Duración (minutos):" : "Goles para ganar:");
        if (spinnerObjetivo != null) {
            // Valores por defecto: 2 minutos o 5 goles, según el tipo de partido.
            spinnerObjetivo.setModel(new SpinnerNumberModel(tipoPartido.equals("Tiempo") ? 2 : 5, 1, 10, 1));
        }
    }
    // ===================== Inicio del juego =====================
    private void iniciarPartida() {
        String res = (String) comboCancha.getSelectedItem();
        if (res.startsWith("Pequeña")) {
            anchoCancha = 800;
            altoCancha = 550;
        }
        else if (res.startsWith("Grande")) {
            anchoCancha = 1200;
            altoCancha = 750;
        }
        else {
            anchoCancha = 1000;
            altoCancha = 650;
        }
        objetivo = ((Number) spinnerObjetivo.getValue()).intValue();
        // El catálogo decide qué poder le toca a cada país.
        Personaje p1 = CatalogoPersonajes.crear(paises.get(indice1));
        Personaje p2 = CatalogoPersonajes.crear(paises.get(indice2));
        try {
            dominio.iniciarPartido(tipoPartido, "PvsP", p1, p2, objetivo, anchoCancha, altoCancha);
            mostrarJuego();
        }
        catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo iniciar", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void mostrarJuego() {
        loop.stop();
        teclasPresionadas.clear();
        panelCancha = new PanelCancha(dominio);
        JPanel pantalla = new JPanel(new BorderLayout());
        JPanel barra = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 6));
        JButton pausa = boton("PAUSAR / REANUDAR");
        pausa.setPreferredSize(new Dimension(220, 40));
        pausa.addActionListener(e -> {
            if (dominio.isPausa()) dominio.reanudarJuego();
            else dominio.pausarJuego();
            // Se devuelve el foco a la cancha para que las teclas sigan respondiendo.
            panelCancha.requestFocusInWindow();
        }
        );
        JButton terminar = boton("TERMINAR PARTIDO");
        terminar.setPreferredSize(new Dimension(190, 40));
        terminar.addActionListener(e -> {
            dominio.getPartidoActual().terminar();
            panelCancha.repaint();
        }
        );
        JButton menu = boton("MENÚ");
        menu.setPreferredSize(new Dimension(120, 40));
        menu.addActionListener(e -> {
            loop.stop();
            cards.show(root, "inicio");
        }
        );
        barra.add(pausa);
        barra.add(terminar);
        barra.add(menu);
        pantalla.add(barra, BorderLayout.NORTH);
        pantalla.add(panelCancha, BorderLayout.CENTER);
        // Si ya había una partida anterior, se retira su pantalla antes de agregar la nueva.
        if (pantallaJuego != null) root.remove(pantallaJuego);
        pantallaJuego = pantalla;
        root.add(pantallaJuego, "juego");
        cards.show(root, "juego");
        setSize(anchoCancha, altoCancha + 95);
        setLocationRelativeTo(null);
        panelCancha.setFocusable(true);
        panelCancha.requestFocusInWindow();
        loop.start();
    }
    // ===================== Controles =====================
    private void instalarControles() {
        // Los key bindings usan WHEN_IN_FOCUSED_WINDOW, así que responden aunque el foco no esté en la cancha.
        bind(KeyEvent.VK_A, "p1left", () -> accion(1, "A"));
        bind(KeyEvent.VK_D, "p1right", () -> accion(1, "D"));
        bind(KeyEvent.VK_W, "p1jump", () -> accion(1, "W"));
        bind(KeyEvent.VK_S, "p1kick", () -> accion(1, "S"));
        bind(KeyEvent.VK_Q, "p1power", () -> accion(1, "Q"));
        bind(KeyEvent.VK_LEFT, "p2left", () -> accion(2, "LEFT"));
        bind(KeyEvent.VK_RIGHT, "p2right", () -> accion(2, "RIGHT"));
        bind(KeyEvent.VK_UP, "p2jump", () -> accion(2, "UP"));
        bind(KeyEvent.VK_DOWN, "p2kick", () -> accion(2, "DOWN"));
    }
    private void bind(int key, String name, Runnable action) {
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key, 0, false), name);
        root.getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Las teclas solo actúan mientras hay una partida en curso y sin pausa.
                Partido actual = dominio.getPartidoActual();
                if (actual != null && !dominio.isPausa() && !actual.isTerminado()) action.run();
            }
        }
        );
    }
    private void accion(int n, String tecla) {
        Partido p = dominio.getPartidoActual();
        if (p == null) return;
        Jugador j = n == 1 ? p.getJugador1() : p.getJugador2();
        j.realizarAccion(tecla, p);
        if (panelCancha != null) panelCancha.repaint();
    }
    private void procesarTeclasContinuas() {
        // Pendiente: el movimiento continuo todavía depende del auto-repeat del teclado.
        Partido p = dominio.getPartidoActual();
        if (p == null) return;
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new POOBSoccerGUI().setVisible(true));
    }
}
