package presentacion;

import Domain.*;
import javax.swing.*;
import java.awt.*;

/** Renderiza la cancha, los países, el marcador, el tiempo y las barras de poder. */
public class PanelCancha extends JPanel {
    private final POOBSoccer dominio;
    public PanelCancha(POOBSoccer d) {
        dominio=d;
        setPreferredSize(new Dimension(1000,650));
        setBackground(new Color(115,190,235));
    }
    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Partido p=dominio.getPartidoActual();
        if(p==null)return;
        Graphics2D x=(Graphics2D)g.create();
        double sx=getWidth()/(double)p.getCancha().getAncho(),sy=getHeight()/(double)p.getCancha().getAlto();
        x.scale(sx,sy);
        dibujarCancha(x,p);
        dibujarArcos(x,p);
        dibujarJugador(x,p.getJugador1(),new Color(35,105,225));
        dibujarJugador(x,p.getJugador2(),new Color(220,65,65));
        dibujarBalon(x,p.getBalon());
        dibujarHUD(x,p);
        if(dominio.isPausa()) {
            x.setColor(new Color(0,0,0,150));
            x.fillRect(0,0,p.getCancha().getAncho(),p.getCancha().getAlto());
            x.setColor(Color.WHITE);
            x.setFont(new Font("Arial",Font.BOLD,44));
            x.drawString("EN PAUSA",p.getCancha().getAncho()/2-115,p.getCancha().getAlto()/2);
        }
        if(p.isTerminado()) {
            x.setColor(new Color(0,0,0,180));
            x.fillRoundRect(p.getCancha().getAncho()/2-230,p.getCancha().getAlto()/2-65,460,130,25,25);
            x.setColor(Color.WHITE);
            x.setFont(new Font("Arial",Font.BOLD,30));
            Jugador win=p.getGanador();
            x.drawString(win==null?"EMPATE":"GANADOR: "+win.getPersonaje().getPais(),p.getCancha().getAncho()/2-195,p.getCancha().getAlto()/2);
            x.setFont(new Font("Arial",Font.PLAIN,18));
            x.drawString("Puntos obtenidos: "+(win==null?25:100),p.getCancha().getAncho()/2-100,p.getCancha().getAlto()/2+35);
        }
        x.dispose();
    }
    private void dibujarCancha(Graphics2D g,Partido p) {
        int w=p.getCancha().getAncho(),h=p.getCancha().getAlto(),floor=p.getCancha().getSuelo();
        g.setPaint(new GradientPaint(0,0,new Color(115,190,235),0,floor,new Color(210,235,250)));
        g.fillRect(0,0,w,h);
        g.setColor(new Color(30,145,65));
        g.fillRect(0,floor,w,h-floor);
        g.setColor(new Color(245,245,245));
        g.setStroke(new BasicStroke(3));
        g.drawLine(0,floor,w,floor);
        g.drawLine(w/2,0,w/2,floor);
        g.drawOval(w/2-65,floor-130,130,130);
        g.drawRect(0,floor-125,110,125);
        g.drawRect(w-110,floor-125,110,125);
        g.setColor(new Color(255,255,255,180));
        g.drawLine(0,0,w,0);
    }
    private void dibujarArcos(Graphics2D g,Partido p) {
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(7));
        Arco a=p.getCancha().getArcoIzquierdo(),b=p.getCancha().getArcoDerecho();
        g.drawRect(a.getPosX(),a.getPosY(),a.getAncho(),a.getAlto());
        g.drawRect(b.getPosX(),b.getPosY(),b.getAncho(),b.getAlto());
    }
    private void dibujarJugador(Graphics2D g,Jugador j,Color color) {
        Personaje p=j.getPersonaje();
        int x=(int)p.getPosX(),y=(int)p.getPosY();
        g.setColor(p.isAturdido()?Color.GRAY:color);
        g.fillRoundRect(x,y,42,64,16,16);
        g.setColor(Color.WHITE);
        g.fillOval(x+8,y+10,8,8);
        g.fillOval(x+26,y+10,8,8);
        g.setColor(Color.BLACK);
        g.drawString(p.getPais(),Math.max(2,x-10),y-10);
        if(j.tienePoderPreparado()) {
            g.setColor(p.getPais().equals("Corea del Sur")?Color.CYAN:Color.YELLOW);
            g.setStroke(new BasicStroke(4));
            g.drawOval(x-9,y-9,60,82);
        }
        if(p.isElectrificado()) {
            g.setColor(Color.YELLOW);
            g.drawString("⚡",x+12,y-18);
        }
        if(p.isAturdido()) {
            g.setColor(Color.WHITE);
            g.drawString("STUN",x,y-22);
        }
    }
    private void dibujarBalon(Graphics2D g,Balon b) {
        int r=b.getRadio(),x=(int)b.getPosX(),y=(int)b.getPosY();
        g.setColor(b.isDisparoEspecial()?Color.CYAN:Color.WHITE);
        g.fillOval(x-r,y-r,r*2,r*2);
        g.setColor(Color.BLACK);
        g.drawOval(x-r,y-r,r*2,r*2);
        if(b.isDisparoEspecial()) {
            g.setColor(Color.YELLOW);
            g.drawLine(x-r-12,y,x-r,y);
        }
    }
    private void dibujarHUD(Graphics2D g,Partido p) {
        int w=p.getCancha().getAncho();
        g.setFont(new Font("Arial",Font.BOLD,24));
        g.setColor(Color.BLACK);
        g.drawString(p.getMarcador()[0]+"  -  "+p.getMarcador()[1],w/2-40,35);
        g.setFont(new Font("Arial",Font.BOLD,15));
        dibujarJugadorHUD(g,p.getJugador1(),25,25,Color.BLUE);
        dibujarJugadorHUD(g,p.getJugador2(),w-225,25,Color.RED);
        if(p instanceof PartidoPorTiempo) {
            PartidoPorTiempo t=(PartidoPorTiempo)p;
            g.setFont(new Font("Arial",Font.BOLD,17));
            String reloj="Tiempo: "+formato(t.getTiempoRestante());
            g.drawString(reloj,w/2-55,62);
            if(t.isEsGolDeOro()) {
                g.setColor(new Color(180,20,20));
                g.setFont(new Font("Arial",Font.BOLD,22));
                g.drawString("¡GOL DE ORO!",w/2-75,91);
            }
        }
    }
    private String formato(int s) {
        return String.format("%02d:%02d",s/60,s%60);
    }
    private void dibujarJugadorHUD(Graphics2D g,Jugador j,int x,int y,Color color) {
        g.setColor(Color.DARK_GRAY);
        g.drawString(j.getPersonaje().getPais(),x,y);
        g.setColor(new Color(70,70,70));
        g.fillRect(x,y+8,190,13);
        g.setColor(color);
        g.fillRect(x,y+8,(int)(190*j.getPersonaje().getVidaActual()/(double)j.getPersonaje().getVidaMaxima()),13);
        g.setColor(Color.DARK_GRAY);
        g.drawString("HP "+j.getPersonaje().getVidaActual()+"   Poder",x,y+39);
        g.setColor(Color.GRAY);
        g.fillRect(x,y+44,190,10);
        g.setColor(Color.ORANGE);
        g.fillRect(x,y+44,(int)(190*j.getBarraPoder()/100.0),10);
        if(j.tienePoderPreparado()) {
            g.setColor(Color.MAGENTA);
            g.drawString("PODER LISTO",x,y+72);
        }
    }
}
