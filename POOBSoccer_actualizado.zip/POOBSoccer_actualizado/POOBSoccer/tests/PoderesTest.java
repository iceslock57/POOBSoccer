package tests;

import Domain.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Pruebas de los poderes especiales y de su efecto real en cada país durante el partido. */
public class PoderesTest {
    private static final double DELTA = 1e-6;
    private static final double MULT = 1.2;
    // multiplicador de kick que da el catálogo (kick 3)
    private static final int VIDA_MAX = 120;
    // survival 3 -> 100 + 10 * 2
    private static final int FPS = 60;
    private static final double EMPUJE = 14;
    // velocidad horizontal que deja aplicarEmpuje
    // ===================== Apoyo =====================
    /** Rival quieto en el suelo y a mitad de una cancha de 1000 px, para observar efectos y empujes. */
    private static Personaje rivalEnReposo() {
        Personaje p = new Personaje("Rival", "Rival", 3, 3, 3, 3, new PoderRayo());
        p.configurarCancha(1000, 564);
        p.resetearPosicion(500, 500);
        return p;
    }
    private static void avanzar(Personaje p, int frames) {
        for (int i = 0; i < frames; i++) p.actualizarEstado();
    }
    private static int danio(double base, double mult) {
        return (int) Math.round(base * mult);
    }
    private static int danioBase(String pais) {
        switch (pais) {
            case "Corea del Sur": return 40;
            case "Camerún": return 60;
            case "Rusia": return 20;
            case "Japón": return 30;
            default: throw new AssertionError("País sin daño esperado definido: " + pais);
        }
    }
    private static double velocidadEsperada(String pais) {
        switch (pais) {
            case "Corea del Sur": return 24;
            case "Camerún": return 12;
            case "Rusia": return 12;
            case "Japón": return 18;
            default: throw new AssertionError("País sin velocidad esperada definida: " + pais);
        }
    }
    private static Jugador jugador(Personaje personaje, boolean primero) {
        String[] teclas = primero
        ? new String[] {
            "A", "D", "W", "S", "Q"
        }
        : new String[] {
            "LEFT", "RIGHT", "UP", "DOWN", "CTRL"
        }
        ;
        return new JugadorHumano(personaje.getNombre(), personaje, teclas);
    }
    private static Partido partido(String paisJ1, String paisJ2) {
        Jugador j1 = jugador(CatalogoPersonajes.crear(paisJ1), true);
        Jugador j2 = jugador(CatalogoPersonajes.crear(paisJ2), false);
        return new PartidoPorGoles(j1, j2, 5);
    }
    /** Pone un disparo especial del jugador "dueno" sobre su rival y avanza el cuadro del impacto. */
    private static void lanzarDisparoSobreElRival(Partido p, int dueno) {
        Personaje rival = (dueno == 1 ? p.getJugador2() : p.getJugador1()).getPersonaje();
        p.getBalon().resetearPosicion(rival.getPosX() + 20, rival.getPosY() + 20);
        p.getBalon().aplicarDisparoEspecial(0, 0, dueno);
        p.actualizarEstado();
    }
    /** El jugador 1 carga el poder, lo activa, patea con el balón encima y avanza un cuadro. */
    private static void patearConPoderPreparado(Partido partido) {
        Jugador atacante = partido.getJugador1();
        atacante.cargarPoder(100);
        atacante.realizarAccion("Q", partido);
        assertTrue(atacante.tienePoderPreparado(), "Precondición: poder preparado");
        patearBalonEncima(partido);
    }
    private static void patearBalonEncima(Partido partido) {
        Personaje p = partido.getJugador1().getPersonaje();
        p.patear();
        partido.getBalon().resetearPosicion(p.getPosX() + 20, p.getPosY() + 20);
        partido.actualizarEstado();
    }
    /** Comprueba daño, estados y empuje que debe producir el poder del país tras el impacto. */
    private static void verificarEfecto(String pais, Partido partido, Personaje rival, double xAntes, int dueno) {
        int direccion = dueno == 1 ? 1 : -1;
        Personaje atacante = (dueno == 1 ? partido.getJugador1() : partido.getJugador2()).getPersonaje();
        boolean aturdido = false, congelado = false, confundido = false, empuja = false;
        switch (pais) {
            case "Corea del Sur":
            empuja = true;
            break;
            case "Camerún":
            aturdido = true;
            break;
            case "Rusia":
            congelado = true;
            break;
            case "Japón":
            confundido = true;
            empuja = true;
            break;
            default:
            throw new AssertionError("País sin efecto esperado definido: " + pais);
        }
        // Un cuadro más para que el empuje, si existe, se refleje en la posición.
        partido.actualizarEstado();
        int vidaEsperada = VIDA_MAX - danio(danioBase(pais), atacante.getMultiplicadorKick());
        assertEquals(vidaEsperada, rival.getVidaActual(), pais + ": daño");
        assertEquals(aturdido, rival.aturdido(), pais + ": aturdimiento");
        assertEquals(congelado, rival.congelado(), pais + ": congelamiento");
        assertEquals(confundido, rival.isConfundido(), pais + ": confusión");
        double xEsperada = empuja ? xAntes + direccion * EMPUJE : xAntes;
        assertEquals(xEsperada, rival.getPosX(), DELTA, pais + ": empuje");
    }
    // ===================== Poderes por separado =====================
    @Test
    public void velocidadDeDisparoDeCadaPoder() {
        assertEquals(24, new PoderAuraAzul().velocidadDisparo(), DELTA, "Aura azul");
        assertEquals(12, new PoderRayo().velocidadDisparo(), DELTA, "Rayo");
        assertEquals(12, new PoderHielo().velocidadDisparo(), DELTA, "Hielo usa la velocidad por defecto");
        assertEquals(18, new PoderTornado().velocidadDisparo(), DELTA, "Tornado");
    }
    @Test
    public void poderAuraAzulHaceDanioYEmpujaSegunLaDireccion() {
        Personaje derecha = rivalEnReposo();
        new PoderAuraAzul().aplicarImpacto(derecha, MULT, 1);
        assertEquals(VIDA_MAX - 48, derecha.getVidaActual(), "Daño de 40 x 1.2");
        avanzar(derecha, 1);
        assertEquals(500 + EMPUJE, derecha.getPosX(), DELTA, "Empuje a la derecha");
        assertFalse(derecha.aturdido() || derecha.congelado() || derecha.isConfundido(), "Sin estados alterados");
        Personaje izquierda = rivalEnReposo();
        new PoderAuraAzul().aplicarImpacto(izquierda, MULT, -1);
        avanzar(izquierda, 1);
        assertEquals(500 - EMPUJE, izquierda.getPosX(), DELTA, "Empuje a la izquierda");
    }
    @Test
    public void poderRayoHaceDanioYAturdeTresSegundos() {
        Personaje rival = rivalEnReposo();
        new PoderRayo().aplicarImpacto(rival, MULT, 1);
        assertEquals(VIDA_MAX - 72, rival.getVidaActual(), "Daño de 60 x 1.2");
        assertTrue(rival.aturdido(), "Queda aturdido");
        assertFalse(rival.congelado(), "No queda congelado");
        avanzar(rival, 1);
        assertEquals(500, rival.getPosX(), DELTA, "El rayo no empuja");
        avanzar(rival, 3 * FPS - 2);
        assertTrue(rival.aturdido(), "Un cuadro antes de los 3 segundos sigue aturdido");
        avanzar(rival, 1);
        assertFalse(rival.aturdido(), "A los 3 segundos exactos se recupera");
    }
    @Test
    public void poderHieloHaceDanioYCongelaTresSegundos() {
        Personaje rival = rivalEnReposo();
        new PoderHielo().aplicarImpacto(rival, MULT, 1);
        assertEquals(VIDA_MAX - 24, rival.getVidaActual(), "Daño de 20 x 1.2");
        assertTrue(rival.congelado(), "Queda congelado");
        assertFalse(rival.aturdido(), "No queda aturdido");
        assertFalse(rival.isConfundido(), "No queda confundido");
        avanzar(rival, 3 * FPS - 1);
        assertTrue(rival.congelado(), "Un cuadro antes de los 3 segundos sigue congelado");
        avanzar(rival, 1);
        assertFalse(rival.congelado(), "A los 3 segundos exactos se descongela");
        assertEquals(VIDA_MAX - 24, rival.getVidaActual(), "Descongelarse no devuelve la vida");
        assertEquals(500, rival.getPosX(), DELTA, "El hielo no empuja");
        Personaje sinMultiplicador = rivalEnReposo();
        new PoderHielo().aplicarEfecto(sinMultiplicador);
        assertEquals(VIDA_MAX - 20, sinMultiplicador.getVidaActual(), "aplicarEfecto sin multiplicador usa 1.0");
        assertTrue(sinMultiplicador.congelado(), "aplicarEfecto sin multiplicador también congela");
    }
    @Test
    public void poderTornadoHaceDanioConfundeYEmpuja() {
        Personaje rival = rivalEnReposo();
        new PoderTornado().aplicarImpacto(rival, MULT, -1);
        assertEquals(VIDA_MAX - 36, rival.getVidaActual(), "Daño de 30 x 1.2");
        assertTrue(rival.isConfundido(), "Queda confundido");
        assertFalse(rival.aturdido() || rival.congelado(), "No queda aturdido ni congelado");
        avanzar(rival, 1);
        assertEquals(500 - EMPUJE, rival.getPosX(), DELTA, "Empuje a la izquierda");
        avanzar(rival, 3 * FPS - 2);
        assertTrue(rival.isConfundido(), "Un cuadro antes de los 3 segundos sigue confundido");
        avanzar(rival, 1);
        assertFalse(rival.isConfundido(), "A los 3 segundos exactos se le pasa la confusión");
        Personaje sinMultiplicador = rivalEnReposo();
        new PoderTornado().aplicarEfecto(sinMultiplicador);
        assertEquals(VIDA_MAX - 30, sinMultiplicador.getVidaActual(), "aplicarEfecto sin multiplicador usa 1.0");
        avanzar(sinMultiplicador, 1);
        assertEquals(500, sinMultiplicador.getPosX(), DELTA, "Sin dirección no hay empuje");
    }
    @Test
    public void elDanioEscalaConElMultiplicadorEnTodosLosPoderes() {
        Poder[] poderes = {
            new PoderAuraAzul(), new PoderRayo(), new PoderHielo(), new PoderTornado()
        }
        ;
        int[] base = {
            40, 60, 20, 30
        }
        ;
        double[] multiplicadores = {
            1.0, 1.5
        }
        ;
        for (int i = 0; i < poderes.length; i++) {
            for (double mult : multiplicadores) {
                Personaje rival = rivalEnReposo();
                poderes[i].aplicarImpacto(rival, mult, 1);
                int esperado = VIDA_MAX - danio(base[i], mult);
                assertEquals(esperado, rival.getVidaActual(),
                poderes[i].getClass().getSimpleName() + " con multiplicador " + mult);
            }
        }
    }
    @Test
    public void elEmpujeNoMueveAUnRivalAturdidoOCongelado() {
        Personaje aturdido = rivalEnReposo();
        aturdido.aturdir(3);
        new PoderAuraAzul().aplicarImpacto(aturdido, MULT, 1);
        avanzar(aturdido, 1);
        assertEquals(VIDA_MAX - 48, aturdido.getVidaActual(), "Aturdido: recibe el daño");
        assertEquals(500, aturdido.getPosX(), DELTA, "Aturdido: no se mueve");
        Personaje congelado = rivalEnReposo();
        congelado.congelar(3);
        new PoderTornado().aplicarImpacto(congelado, MULT, 1);
        avanzar(congelado, 1);
        assertEquals(VIDA_MAX - 36, congelado.getVidaActual(), "Congelado: recibe el daño");
        assertEquals(500, congelado.getPosX(), DELTA, "Congelado: no se mueve");
    }
    @Test
    public void laInterfazPorDefectoDelegaEnAplicarEfectoYUsaVelocidadNormal() {
        int[] llamadas = {
            0
        }
        ;
        Poder minimo = new Poder() {
            @Override
            public void aplicarEfecto(Personaje objetivo) {
                llamadas[0]++;
                objetivo.recibirDanio(10);
            }
        }
        ;
        Personaje rival = rivalEnReposo();
        assertEquals(12, minimo.velocidadDisparo(), DELTA, "Velocidad por defecto");
        minimo.aplicarEfecto(rival, 2.0);
        minimo.aplicarImpacto(rival, 2.0, 1);
        assertEquals(2, llamadas[0], "Las dos variantes delegan en aplicarEfecto(Personaje)");
        assertEquals(VIDA_MAX - 20, rival.getVidaActual(), "Cada llamada hizo 10 de daño");
    }
    // ===================== Efecto de cada país en el partido =====================
    @Test
    public void disparoEspecialDeCadaPaisAplicaSuEfectoAlRival() {
        for (String pais : CatalogoPersonajes.paises()) {
            Partido partido = partido(pais, "Camerún");
            Personaje rival = partido.getJugador2().getPersonaje();
            double xAntes = rival.getPosX();
            lanzarDisparoSobreElRival(partido, 1);
            assertFalse(partido.getBalon().isDisparoEspecial(), pais + ": el disparo se consume al impactar");
            verificarEfecto(pais, partido, rival, xAntes, 1);
        }
    }
    @Test
    public void elEmpujeDependeDeQuienLanzaElDisparo() {
        for (String pais : new String[] {
            "Corea del Sur", "Japón"
        }
        ) {
            Partido comoJugador1 = partido(pais, "Camerún");
            Personaje rivalDerecha = comoJugador1.getJugador2().getPersonaje();
            double x1 = rivalDerecha.getPosX();
            lanzarDisparoSobreElRival(comoJugador1, 1);
            comoJugador1.actualizarEstado();
            assertEquals(x1 + EMPUJE, rivalDerecha.getPosX(), DELTA, pais + " como jugador 1 empuja a la derecha");
            Partido comoJugador2 = partido("Camerún", pais);
            Personaje rivalIzquierda = comoJugador2.getJugador1().getPersonaje();
            double x2 = rivalIzquierda.getPosX();
            lanzarDisparoSobreElRival(comoJugador2, 2);
            comoJugador2.actualizarEstado();
            assertEquals(x2 - EMPUJE, rivalIzquierda.getPosX(), DELTA, pais + " como jugador 2 empuja a la izquierda");
        }
    }
    @Test
    public void sinImpactoNingunPoderAfectaAlRival() {
        for (String pais : CatalogoPersonajes.paises()) {
            Partido partido = partido(pais, "Camerún");
            Personaje rival = partido.getJugador2().getPersonaje();
            partido.getBalon().aplicarDisparoEspecial(0, 0, 1);
            for (int i = 0; i < 5; i++) partido.actualizarEstado();
            assertTrue(partido.getBalon().isDisparoEspecial(), pais + ": el disparo sigue activo");
            assertEquals(VIDA_MAX, rival.getVidaActual(), pais + ": el rival no pierde vida");
            assertFalse(rival.aturdido() || rival.congelado() || rival.isConfundido(), pais + ": sin estados");
        }
    }
    // ===================== Velocidad al patear =====================
    @Test
    public void disparoEspecialAlPatearSaleConLaVelocidadDelPoderDeCadaPais() {
        for (String pais : CatalogoPersonajes.paises()) {
            Partido partido = partido(pais, "Camerún");
            patearConPoderPreparado(partido);
            Balon balon = partido.getBalon();
            assertTrue(balon.isDisparoEspecial(), pais + ": el balón sale como disparo especial");
            assertEquals(1, balon.getPropietarioDisparo(), pais + ": propietario del disparo");
            assertEquals(velocidadEsperada(pais), balon.getVelX(), DELTA, pais + ": velocidad horizontal");
            assertFalse(partido.getJugador1().tienePoderPreparado(), pais + ": el poder se consume");
        }
    }
    @Test
    public void sinPoderPreparadoLaPatadaEsNormalParaTodosLosPaises() {
        for (String pais : CatalogoPersonajes.paises()) {
            Partido partido = partido(pais, "Camerún");
            patearBalonEncima(partido);
            Balon balon = partido.getBalon();
            assertFalse(balon.isDisparoEspecial(), pais + ": patada normal");
            assertEquals(12, balon.getVelX(), DELTA, pais + ": velocidad normal");
        }
    }
    // ===================== El efecto depende del poder, no del país =====================
    @Test
    public void elEfectoDependeDelPoderYNoDelNombreDelPais() {
        // Dice ser de Corea, pero con poder de hielo debe congelar y disparar a velocidad normal.
        Personaje falsoCorea = new Personaje("Falso", "Corea del Sur", 3, 3, 3, 3, new PoderHielo());
        Partido hielo = new PartidoPorGoles(jugador(falsoCorea, true), jugador(CatalogoPersonajes.crear("Camerún"), false), 5);
        Personaje rivalHielo = hielo.getJugador2().getPersonaje();
        double x = rivalHielo.getPosX();
        lanzarDisparoSobreElRival(hielo, 1);
        hielo.actualizarEstado();
        assertTrue(rivalHielo.congelado(), "El poder de hielo congela aunque el país sea Corea");
        assertEquals(VIDA_MAX - 24, rivalHielo.getVidaActual(), "Daño del hielo");
        assertEquals(x, rivalHielo.getPosX(), DELTA, "Sin empuje de Corea");
        Personaje falsoCorea2 = new Personaje("Falso", "Corea del Sur", 3, 3, 3, 3, new PoderHielo());
        Partido patada = new PartidoPorGoles(jugador(falsoCorea2, true), jugador(CatalogoPersonajes.crear("Camerún"), false), 5);
        patearConPoderPreparado(patada);
        assertEquals(12, patada.getBalon().getVelX(), DELTA, "No hereda la velocidad 24 de Corea");
        // Un país que antes no tenía ningún efecto ahora lo toma de su poder.
        Personaje brasil = new Personaje("Brasil", "Brasil", 3, 3, 3, 3, new PoderRayo());
        Partido rayo = new PartidoPorGoles(jugador(brasil, true), jugador(CatalogoPersonajes.crear("Camerún"), false), 5);
        Personaje rivalRayo = rayo.getJugador2().getPersonaje();
        lanzarDisparoSobreElRival(rayo, 1);
        assertTrue(rivalRayo.aturdido(), "El rayo aturde aunque el país no esté en el catálogo");
        assertEquals(VIDA_MAX - 72, rivalRayo.getVidaActual(), "Daño del rayo");
    }
    @Test
    public void personajeSinPoderNoFallaAlImpactarNiAlPatear() {
        Personaje sinPoder = new Personaje("Sin", "Sin", 3, 3, 3, 3, null);
        Partido impacto = new PartidoPorGoles(jugador(sinPoder, true), jugador(CatalogoPersonajes.crear("Camerún"), false), 5);
        Personaje rival = impacto.getJugador2().getPersonaje();
        assertDoesNotThrow(() -> lanzarDisparoSobreElRival(impacto, 1), "Impacto sin poder");
        assertEquals(VIDA_MAX, rival.getVidaActual(), "El rival no recibe daño");
        assertFalse(rival.aturdido() || rival.congelado() || rival.isConfundido(), "El rival no recibe estados");
        assertFalse(impacto.getBalon().isDisparoEspecial(), "El disparo igual se consume");
        Personaje otroSinPoder = new Personaje("Sin", "Sin", 3, 3, 3, 3, null);
        Partido patada = new PartidoPorGoles(jugador(otroSinPoder, true), jugador(CatalogoPersonajes.crear("Camerún"), false), 5);
        assertDoesNotThrow(() -> patearBalonEncima(patada), "Patada sin poder");
        assertEquals(12, patada.getBalon().getVelX(), DELTA, "Velocidad normal");
    }
}
